package xyz.view;

import javax.swing.*;

public class GameFrame extends JFrame {
    public GameFrame() {
        setTitle("Mine clearance");
        setSize(818, 845);
        setLocationRelativeTo(null); // Center the window.
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(null);
    }
}
