#include <string>
using namespace std;

void generate(const char* dir);

bool china(string line);