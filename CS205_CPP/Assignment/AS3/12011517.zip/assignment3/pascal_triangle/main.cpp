#include <iostream>
#include "pascal.h"

using namespace std;

int main(){
    cout << "pascal(0,0) = " << pascal(0,0) << endl;
    cout << "pascal(0,5) = " << pascal(0,5) << endl;
    cout << "pascal(3,2) = " << pascal(3,2) << endl;
    cout << "pascal(4,2) = " << pascal(4,2) << endl;
    cout << "pascal(5,3) = " << pascal(5,3) << endl;
    cout << "pascal(7,3) = " << pascal(7,3) << endl;
}