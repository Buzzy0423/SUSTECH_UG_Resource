#include <iostream>
#include <string>
#include <algorithm>
#include <fstream>
#include "Lab5.h"

using namespace std;

//int main() {
//    sum();
//    done();
//    word();
//    file();
//    return 0;
//}

void done() {
    int num = 0;
    string str;
    printf("Enter words(to stop, type the word done):\n");
    while (true) {
        cin >> str;
        if (str == "done") {
            break;
        }
        num++;
    }
    printf("You entered a total of %d words.", num);
}

void sum() {
    int num = 0;
    int tmp;
    while (true) {
        printf("Enter an integer number:");
        scanf("%d", &tmp);
        num += tmp;
        printf("The cumulative sum of the entries to date is:%d\n", num);
        if (tmp == 0) {
            break;
        }
    }
}

void word() {
    printf("Enter word (q to quit):\n");
    int nVowel = 0;
    int nConsonant = 0;
    int nOthers = 0;
    char word[30];

    while (cin >> word) {
        if (isalpha(word[0])) {
            if (strlen(word) == 1 && word[0] == 'q') {
                break;
            }
            char x = tolower(word[0]);
            if (find(begin(vowel), end(vowel), x) != end(vowel)) {
                nVowel++;
            } else {
                nConsonant++;
            }
        } else {
            nOthers++;
        }
    }
    printf("%d words beginning with vowels\n%d words beginning with consonants\n%d others", nVowel, nConsonant,
           nOthers);
}

void file() {
    printf("Please input a string:");
    string str;
    ofstream outfile;
    getline(cin, str);
    str.erase(remove_if(str.begin(), str.end(), pred), str.end());
    outfile.open("f1.txt");
    outfile << str << endl;
    outfile.close();
    cout << "The contents of f1.txt : " << str << endl;
    transform(str.begin(), str.end(), str.begin(), ::toupper);
    outfile.open("f2.txt");
    outfile << str << endl;
    cout << "The contents of f2.txt : " << str << endl;
}

char pred(char c) {
    return !(isalpha(c) || c == ' ');
}