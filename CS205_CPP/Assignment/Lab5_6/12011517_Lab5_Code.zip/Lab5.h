#ifndef CPP_LAB5_6_LAB5_H
#define CPP_LAB5_6_LAB5_H

#endif //CPP_LAB5_6_LAB5_H

void sum();

void done();

void word();

void file();

char pred(char c);

const int vn = 5;
const char vowel[vn] = {'a', 'e', 'i', 'o', 'u'};