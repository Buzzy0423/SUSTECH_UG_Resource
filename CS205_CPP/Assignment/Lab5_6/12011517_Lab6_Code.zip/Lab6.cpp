#include <iostream>
#include <string>
#include "Lab6.h"

using namespace std;

//int main() {
//    calculator();
//    box *b = new box;
//    strcpy(b->maker, "apple");
//    b->height = 3.4;
//    b->width = 4.5;
//    b->length = 5.6;
//    set_print(b);
//    array_test();
//    return 0;
//}

void calculator() {
    Displaymenu();
    int YourChoice;
    int a, b;
    char confirm;
    do {
        cout << "Enter your choice(1~5):";
        cin >> YourChoice;
        cout << "Enter your integer numbers:";
        cin >> a >> b;
        cout << "\n";
        printf("Result:");
        switch (YourChoice) {
            case 1:
                cout << Add(a, b);
                break;
            case 2:
                cout << Substract(a, b);
                break;
            case 3:
                cout << Multiply(a, b);
                break;
            case 4:
                cout << Divide(a, b);
                break;
            case 5:
                cout << Modulus(a, b);
                break;
        }
        cout << "\n";
        cout << "Press y or Y to continue:";
        cin >> confirm;
    } while (confirm == 'y' || confirm == 'Y');
}

void Displaymenu() {
    printf("=========================================================\n");
    printf("                          Menu                           \n");
    printf("=========================================================\n");
    printf("    1.Add\n    2.Subtract\n    3.Multiply\n    4.Divide\n    5.Modulus\n");
}

int Add(int a, int b) {
    return a + b;
}

int Substract(int a, int b) {
    return a - b;
}

int Multiply(int a, int b) {
    return a * b;
}

int Divide(int a, int b) {
    return a / b;
}

int Modulus(int a, int b) {
    return a % b;
}

void print_box(box b) {
    cout << "Maker: " << b.maker << endl;
    cout << "Height: " << b.height << endl;
    cout << "Width: " << b.width << endl;
    cout << "Length: " << b.length << endl;
    cout << "Volume: " << b.volume << endl;
}

void set_box_volume(box *b) {
    b->volume = b->length * b->width * b->height;
}

void set_print(box *b) {
    cout << "Before setting volume: " << endl;
    print_box(*b);
    set_box_volume(b);
    cout << "After setting volume: " << endl;
    print_box(*b);
}

int fill_array(double arr[], int size) {
    double d;
    int num = 0;
    try {
        for (int i = 0; i < size; ++i) {
            cout << "Enter value #" << i + 1 << ": ";
            if (cin >> d){
                arr[i] = d;
                num++;
            } else{
                throw -1;
            }
        }
        cout << "Actual number of entries: " << size << endl;
    } catch (...) {
        cout << "Actual number of entries: " << num << endl;
    }
}

void show_array(double *arr, int size) {
    for (int i = 0; i < size; ++i) {
        cout << *(arr + i) << " ";
    }
    cout << "\n";
}

void reverse_array(double *arr, int size) {
    if (size < 2) {
        return;
    }
    swap(*arr, *(arr + size - 1));
    reverse_array(arr + 1, size - 2);
}

void array_test() {
    int size;
    double *arr;
    cout << "Enter the size of array: ";
    cin >> size;
    arr = new double[size];
    fill_array(arr, size);
    show_array(arr, size);
    reverse_array(arr, size);
    show_array(arr, size);
}