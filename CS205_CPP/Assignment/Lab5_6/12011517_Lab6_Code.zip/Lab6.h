#ifndef CPP_LAB5_6_LAB6_H
#define CPP_LAB5_6_LAB6_H

#endif //CPP_LAB5_6_LAB6_H

struct box {
    char maker[40];
    float height;
    float width;
    float length;
    float volume;
};

void calculator();

void Displaymenu();

int Add(int a, int b);

int Substract(int a, int b);

int Multiply(int a, int b);

int Divide(int a, int b);

int Modulus(int a, int b);

void print_box(box b);

void set_box_volume(box *b);

void set_print(box *b);

int fill_array(double arr[], int size);

void show_array(double *arr, int size);

void reverse_array(double *arr, int size);

void array_test();