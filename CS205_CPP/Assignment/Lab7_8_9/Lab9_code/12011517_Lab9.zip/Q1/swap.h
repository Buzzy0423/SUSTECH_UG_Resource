void useless_swap(int a, int b);

void swap(int *a, int *b);

void swap(int &a, int &b);